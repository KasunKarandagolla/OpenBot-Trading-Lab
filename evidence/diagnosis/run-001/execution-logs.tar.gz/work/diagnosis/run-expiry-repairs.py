import subprocess,json,datetime,pathlib
root=pathlib.Path('/lab');work=root/'work/diagnosis'
jobs=[['development','passive-30m','--short'],['development','passive-30m','--short','--detail'],['earlier','passive-30m'],['later','passive-30m'],['development','v4','--replay-id','lifecycle-audit'],['development','passive','--replay-id','lifecycle-audit']]
for i,args in enumerate(jobs):
    command=['python','scripts/diagnosis_native_v2.py',*args]
    log=work/'logs'/f'expiry-repair-{i}.txt'
    with log.open('x') as f: result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
    with (work/'command-history.jsonl').open('a') as f:f.write(json.dumps(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),category='expiry-plumbing-addendum',args=command,returncode=result.returncode,log=str(log)))+'\n')
    print(args,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
